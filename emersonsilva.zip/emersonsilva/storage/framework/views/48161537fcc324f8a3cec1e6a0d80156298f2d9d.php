<?php $__env->startSection('conteudo'); ?>
	<div class="container" >
	<!--    Mensagens após a tentativa de salvar no BD-->
	<?php if(session('success')): ?>
	<div class="alert alert-success" style="text-align:center"><?php echo e(session('success')); ?></div>
	<?php endif; ?>

	<?php if(session('error')): ?>
	<div class="alert alert-danger" style="text-align:center"><?php echo e(session('error')); ?></div>
	<?php endif; ?>
		<form action="<?php echo e(url('/adicionar')); ?>" method="POST" >
		<?php echo csrf_field(); ?>
		  <div class="row">
			<div class="col">
				<label for="inputState">Nome do novo vendedor</label>
				<input type="text" id="vendedor" required name="vendedor_nome" class="form-control" placeholder="Novo vendedor">
			</div>
			<div class="col">
				<label for="inputState">Patrocinadores disponíveis</label>
				  <select id="patrocionador" class="form-control" name="patrocinador_id">
					<?php $__empty_1 = true; $__currentLoopData = $vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<?php if($vendedor->filhoesquerda == null || $vendedor->filhodireita == null): ?>
						<option value="<?php echo e($vendedor->id); ?>"><?php echo e($vendedor->nome); ?></option>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<option value="0">Primeiro a ser cadastrado!</option>   
					<?php endif; ?>
				  </select>
			</div>
		  </div>
		  <div class="form-group" style="margin-top:10px">
			<button type="submit" class="btn btn-primary">Adicionar</button>
		  </div>
		</form>
		<hr/>
		
		<div>
		<h1 style="text-align:center">Relatório<h1/>
		<form action="<?php echo e(url('/gerar-relatorio')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<button type="submit" class="btn btn-success">Atualizar relatório</button>
		</form>		
		</div>
		<hr/>
		
		<table class="table table-sm table-hover table-bordered">
		  <thead>
			<tr>
			  <th scope="col">#</th>
			  <th scope="col">Vendedor</th>
			  <th scope="col">Pontos Perna Menor</th>
			  <th scope="col">Nível</th>
			</tr>
		  </thead>
		  <tbody>
			<!-- relatório -->
			<?php $__empty_1 = true; $__currentLoopData = $vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<tr>
				<th scope="row"><?php echo e($vendedor->id); ?></th>				
				<td><?php echo e($vendedor->nome); ?></td>
				<td><?php echo e($vendedor->pontos); ?></td>
				<td><?php echo e($vendedor->plano); ?></td>
			</tr>	
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<tr>
				<th scope="row"></th>
				<td></td>
				<td></td>
				<td></td>
			</tr>
			<?php endif; ?>
		  </tbody>
		</table>	
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>